﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Domains.Entities
{
    public class FunctionAResponse
    {
        public string Status { get; set; }
    }
}
