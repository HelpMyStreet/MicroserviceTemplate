﻿using AutoMapper;
using $ext_projectname$.Core.Interfaces.Repositories;
using $ext_projectname$.Handlers;
using $ext_projectname$.Mappers;
using $ext_projectname$.Repo;
using MediatR;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

[assembly: FunctionsStartup(typeof($safeprojectname$.Startup))]
namespace $safeprojectname$
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddMediatR(typeof(FunctionAHandler).Assembly);
            builder.Services.AddAutoMapper(typeof(AddressDetailsProfile).Assembly);

            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                   options.UseInMemoryDatabase(databaseName: "$safeprojectname$"));
            builder.Services.AddTransient<IRepository, Repository>();
        }
    }
}